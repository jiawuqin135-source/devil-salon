/* Short procedural effects: no media files, requests or embedded audio data. */
(function(root){'use strict';
const tunes={snip:[1600,950],ring:[880,660,880],warning:[640,420,640],heartbeat:[90,70],start:[440],go:[660,990],magic:[523,659,784,1047],dodge:[880,1320],win:[523,659,784,1047,1319],lose:[440,330,220,110],sip:[420,560,400],page:[1200,800]};
class SoundBank{
 constructor(enabled=true){this.supported=!!(root.AudioContext||root.webkitAudioContext);this.enabled=enabled&&this.supported;this.sources=new Set();this.ctx=null;}
 unlock(){if(!this.enabled||!this.supported)return;try{if(!this.ctx)this.ctx=new(root.AudioContext||root.webkitAudioContext)();if(this.ctx.state==='suspended'){const resume=this.ctx.resume();if(resume&&resume.catch)resume.catch(()=>{});}}catch(error){this.supported=false;this.enabled=false;}}
 setEnabled(value){this.enabled=value&&this.supported;if(!this.enabled)this.stop();else this.unlock();}
 stop(){for(const source of this.sources){try{source.stop();}catch(error){}}this.sources.clear();}
 play(name){if(!this.enabled||!this.ctx||this.ctx.state!=='running'||!tunes[name])return;const notes=tunes[name],beat=name==='snip'?.025:name==='heartbeat'?.09:.085;const ctx=this.ctx;notes.forEach((frequency,i)=>{try{const source=ctx.createOscillator(),gain=ctx.createGain(),at=ctx.currentTime+i*beat;source.type=(name==='snip'||name==='page')?'triangle':'sine';source.frequency.setValueAtTime(frequency,at);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(name==='heartbeat'?.08:.045,at+.008);gain.gain.exponentialRampToValueAtTime(.0001,at+beat);source.connect(gain);gain.connect(ctx.destination);this.sources.add(source);source.onended=()=>{this.sources.delete(source);source.disconnect();gain.disconnect();};source.start(at);source.stop(at+beat+.01);}catch(error){}});}
}root.SalonSound=SoundBank;
})(window);
